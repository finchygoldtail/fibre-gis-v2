import React from "react";
import type { SavedMapAsset } from "../types";

type Props = {
  showAssetPanelButton: boolean;
  onOpenAssetPanel: () => void;

  searchQuery: string;
  setSearchQuery: React.Dispatch<React.SetStateAction<string>>;
  isSearchFocused: boolean;
  setIsSearchFocused: React.Dispatch<React.SetStateAction<boolean>>;
  searchResults: SavedMapAsset[];
  selectedAssetId?: string | null;
  searchScopeLabel: string;
  onSearchSubmit: () => void;
  onSelectSearchResult: (asset: SavedMapAsset) => void;

  canSaveMap: boolean;
  isSavingMap: boolean;
  onSaveMap: () => void;
  onGpsLocate: () => void;
  isLayersOpen: boolean;
  onToggleLayers: () => void;
};

function getAssetSearchLabel(asset: SavedMapAsset): string {
  const item = asset as any;
  return String(
    item.name ||
      item.label ||
      item.jointName ||
      item.address ||
      item.properties?.address ||
      item.uprn ||
      item.UPRN ||
      asset.id ||
      "Asset",
  );
}

function getAssetSearchTypeLabel(asset: SavedMapAsset): string {
  const item = asset as any;
  const typeText = String(
    item.assetType || item.type || item.jointType || item.homeType || "asset",
  );

  return typeText
    .replace(/-/g, " ")
    .replace(/\b\w/g, (match) => match.toUpperCase());
}

export default function MapToolbar({
  showAssetPanelButton,
  onOpenAssetPanel,
  searchQuery,
  setSearchQuery,
  isSearchFocused,
  setIsSearchFocused,
  searchResults,
  selectedAssetId,
  searchScopeLabel,
  onSearchSubmit,
  onSelectSearchResult,
  canSaveMap,
  isSavingMap,
  onSaveMap,
  onGpsLocate,
  isLayersOpen,
  onToggleLayers,
}: Props) {
  return (
    <div style={mapTopBarStyle(isLayersOpen)}>
      {showAssetPanelButton ? (
        <button onClick={onOpenAssetPanel} style={topBarGhostButtonStyle}>
          ☰ Assets
        </button>
      ) : null}

      <div style={mapTopBarBrandStyle}>
        <strong>Alistra GIS</strong>
        <span>{searchScopeLabel}</span>
      </div>

      <div style={searchShellStyle}>
        <div style={searchCardStyle}>
          <div style={searchInputRowStyle}>
            <div aria-hidden="true" style={searchIconStyle}>
              ⌕
            </div>

            <input
              value={searchQuery}
              onFocus={() => setIsSearchFocused(true)}
              onChange={(event) => {
                setSearchQuery(event.target.value);
                setIsSearchFocused(true);
              }}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  event.preventDefault();
                  onSearchSubmit();
                }

                if (event.key === "Escape") {
                  setIsSearchFocused(false);
                }
              }}
              placeholder="Search assets, address or UPRN..."
              style={searchInputStyle}
            />

            <button
              type="button"
              title="Search options"
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => setIsSearchFocused((value) => !value)}
              style={searchOptionsButtonStyle}
            >
              ☷
            </button>
          </div>

          {isSearchFocused && (
            <div style={searchResultsStyle}>
              <div style={searchHintStyle}>
                {searchQuery.trim().length >= 2
                  ? `Search results · ${searchScopeLabel}`
                  : `Searching in: ${searchScopeLabel}`}
              </div>

              {searchQuery.trim().length >= 2 ? (
                searchResults.length > 0 ? (
                  searchResults.map((asset) => (
                    <button
                      key={asset.id}
                      type="button"
                      onMouseDown={(event) => event.preventDefault()}
                      onClick={() => onSelectSearchResult(asset)}
                      style={{
                        ...searchResultButtonStyle,
                        background:
                          asset.id === selectedAssetId ? "#eff6ff" : "#ffffff",
                      }}
                    >
                      <span style={searchResultIconStyle}>
                        {getAssetSearchTypeLabel(asset)
                          .slice(0, 2)
                          .toUpperCase()}
                      </span>

                      <span style={searchResultNameStyle}>
                        {getAssetSearchLabel(asset)}
                      </span>

                      <span style={searchResultTypeStyle}>
                        {getAssetSearchTypeLabel(asset)}
                      </span>
                    </button>
                  ))
                ) : (
                  <div style={emptyResultsStyle}>
                    No matching asset, chamber, pole, DP, cable, address or UPRN
                    found.
                  </div>
                )
              ) : null}
            </div>
          )}
        </div>
      </div>

      <div style={topRightActionsStyle}>
        {canSaveMap && (
          <button
            onClick={onSaveMap}
            disabled={isSavingMap}
            style={{
              ...actionButtonStyle,
              background: isSavingMap ? "#64748b" : "#16a34a",
              cursor: isSavingMap ? "not-allowed" : "pointer",
            }}
            title="Admin-only manual save"
          >
            {isSavingMap ? "Saving..." : "Save Map"}
          </button>
        )}

        <button onClick={onGpsLocate} style={actionButtonStyle}>
          GPS
        </button>

        <button
          onClick={onToggleLayers}
          style={{
            ...actionButtonStyle,
            background: "#2563eb",
          }}
        >
          {isLayersOpen ? "Hide Layers" : "Layers"}
        </button>
      </div>
    </div>
  );
}

const mapTopBarStyle = (isLayersOpen: boolean): React.CSSProperties => ({
  position: "absolute",
  top: 0,
  left: 0,
  right: isLayersOpen ? 286 : 0,
  zIndex: 1300,
  height: 72,
  display: "grid",
  gridTemplateColumns: "minmax(180px, 280px) auto minmax(300px, 590px) auto",
  alignItems: "center",
  gap: 10,
  padding: "8px 12px",
  border: "1px solid rgba(148,163,184,0.42)",
  borderTop: "0",
  borderLeft: "0",
  borderRadius: "0 0 16px 0",
  background: "rgba(15, 23, 42, 0.94)",
  boxShadow: "0 14px 34px rgba(15,23,42,0.34)",
  backdropFilter: "blur(10px)",
  overflow: "visible",
});

const topBarGhostButtonStyle: React.CSSProperties = {
  background: "rgba(30, 41, 59, 0.95)",
  color: "white",
  border: "1px solid rgba(148,163,184,0.34)",
  padding: "10px 12px",
  borderRadius: 12,
  cursor: "pointer",
  fontWeight: 900,
  whiteSpace: "nowrap",
};

const mapTopBarBrandStyle: React.CSSProperties = {
  display: "grid",
  gap: 2,
  minWidth: 118,
  color: "#f8fafc",
  whiteSpace: "nowrap",
};

const searchShellStyle: React.CSSProperties = {
  position: "relative",
  zIndex: 1400,
  width: "100%",
  minWidth: 280,
  alignSelf: "center",
};

const searchCardStyle: React.CSSProperties = {
  position: "relative",
  background: "#ffffff",
  border: "1px solid rgba(148,163,184,0.55)",
  borderRadius: 12,
  boxShadow: "0 10px 24px rgba(15,23,42,0.22)",
  overflow: "visible",
};

const searchInputRowStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "40px minmax(0, 1fr) 40px",
  alignItems: "center",
  height: 42,
};

const searchIconStyle: React.CSSProperties = {
  color: "#0f172a",
  fontSize: 22,
  textAlign: "center",
  lineHeight: "42px",
};

const searchInputStyle: React.CSSProperties = {
  width: "100%",
  boxSizing: "border-box",
  border: "none",
  background: "transparent",
  color: "#0f172a",
  padding: "0 6px",
  fontSize: 15,
  fontWeight: 800,
  outline: "none",
};

const searchOptionsButtonStyle: React.CSSProperties = {
  border: "none",
  background: "transparent",
  color: "#0f172a",
  cursor: "pointer",
  fontSize: 19,
  fontWeight: 900,
  height: 42,
};

const searchScopeStyle: React.CSSProperties = {
  display: "none",
};

const searchResultsStyle: React.CSSProperties = {
  position: "absolute",
  top: "calc(100% + 6px)",
  left: 0,
  right: 0,
  border: "1px solid #e5e7eb",
  borderRadius: "0 0 12px 12px",
  maxHeight: 380,
  overflowY: "auto",
  background: "#ffffff",
  boxShadow: "0 18px 38px rgba(15,23,42,0.25)",
};

const searchHintStyle: React.CSSProperties = {
  padding: "10px 22px 6px",
  color: "#94a3b8",
  fontSize: 11,
  fontWeight: 900,
  letterSpacing: 0.5,
  textTransform: "uppercase",
};

const searchResultButtonStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "34px minmax(0, 1fr) auto",
  alignItems: "center",
  gap: 12,
  width: "100%",
  textAlign: "left",
  border: "none",
  borderTop: "1px solid #f1f5f9",
  color: "#0f172a",
  padding: "10px 22px",
  cursor: "pointer",
};

const searchResultIconStyle: React.CSSProperties = {
  display: "inline-grid",
  placeItems: "center",
  width: 28,
  height: 28,
  borderRadius: 7,
  background: "#2563eb",
  color: "#ffffff",
  fontSize: 11,
  fontWeight: 900,
};

const searchResultNameStyle: React.CSSProperties = {
  overflow: "hidden",
  textOverflow: "ellipsis",
  whiteSpace: "nowrap",
  fontWeight: 900,
};

const searchResultTypeStyle: React.CSSProperties = {
  color: "#64748b",
  fontSize: 13,
  fontWeight: 700,
  whiteSpace: "nowrap",
};

const emptyResultsStyle: React.CSSProperties = {
  color: "#64748b",
  padding: "12px 22px 18px",
  fontSize: 13,
};

const topRightActionsStyle: React.CSSProperties = {
  display: "flex",
  gap: 8,
  alignItems: "center",
  justifyContent: "flex-end",
  minWidth: 0,
};

const actionButtonStyle: React.CSSProperties = {
  background: "#2563eb",
  color: "white",
  border: "none",
  padding: "10px 13px",
  borderRadius: 10,
  cursor: "pointer",
  boxShadow: "0 2px 8px rgba(0,0,0,0.26)",
  fontWeight: 900,
  whiteSpace: "nowrap",
};
